process.on("uncaughtException", console.error);
require('./settings');

const { default: 
	makeWASocket, 
	makeCacheableSignalKeyStore, 
	useMultiFileAuthState, 
	DisconnectReason, 
	fetchLatestBaileysVersion, 
	generateForwardMessageContent, 
	generateWAMessage, 
	prepareWAMessageMedia, 
	generateWAMessageFromContent, 
	generateMessageID, 
	getContentType,
	downloadContentFromMessage, 
	makeInMemoryStore, 
	jidDecode, 
	proto, 
	delay,
	Browsers 
} = require(global.WHATSAPP_API);

const {
	fetchSecurityData,
	fetchUserData,
	authenticateUserWithDomain,
	question,
	authenticateUser,
	rainbowColors,
	rainbowText
} = require('cloud-security');

const { color } = require('./lib/color');
const readline = require("readline");
const NodeCache = require("node-cache");
const msgRetryCounterCache = new NodeCache();
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const { Low, JSONFile } = require('./lib/lowdb');
const yargs = require('yargs/yargs');
const fs = require('fs');
const chalk = require('chalk');
const FileType = require('file-type');
const path = require('path');
const axios = require('axios');
const _ = require('lodash');
const util = require('util');
const os = require('os');
const moment = require('moment-timezone');
const PhoneNumber = require('awesome-phonenumber');

const { 
	addExif, 
	imageToWebp, 
	videoToWebp, 
	imageToWebpV2, 
	videoToWebpV2, 
	writeExifImg, 
	writeExifVid, 
	writeExifImgV2, 
	writeExifVidV2, 
	writeExif 
} = require('./lib/exif');

const { 
	smsg, 
	await, 
	clockString, 
	enumGetKey, 
	fetchBuffer, 
	fetchJson, 
	format, 
	formatDate, 
	formatp, 
	generateProfilePicture, 
	getBuffer, 
	getGroupAdmins, 
	getRandom, 
	getSizeMedia, 
	isUrl, 
	json, 
	logic, 
	msToDate, 
	ments, 
	sizeLimit, 
	sleep, 
	sort, 
	toNumber 
} = require('./lib/myfunc');

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());

global.db = new Low(new JSONFile(`src/${tempatDB}`));

global.DATABASE = global.db;

global.muatDatabase = async function muatDatabase() {
	if (global.db.READ) {
		return new Promise((resolve) => {
			const interval = setInterval(() => {
				if (!global.db.READ) {
					clearInterval(interval);
					resolve(global.db.data == null ? global.muatDatabase() : global.db.data);
				}
			}, 1000);
		});
	}

	if (global.db.data !== null) return;

	global.db.READ = true;

	try {
		await global.db.read();
		global.db.data = {
			users: {},
			rpg: {},
			database: {},
			chats: {},
			game: {},
			settings: {},
			message: {},
			...(global.db.data || {})
		};
		global.db.chain = _.chain(global.db.data);
	} catch (err) {
		console.error('⚠️ Gagal membaca database:', err);
	} finally {
		global.db.READ = false;
	}
};

muatDatabase();

if (global.db) {
	setInterval(async () => {
		if (global.db.data && !global.db.READ) {
			try {
				await global.db.write();
			} catch (err) {
				console.error('⚠️ Gagal menyimpan database:', err);
			}
		}
	}, 30 * 1000);
}

const phoneNumber = ownerNumber;
const usePairingCode = true;
const session = `./${sessionName}`;
const storeFilePath = path.join(session, 'store.json');

if (!fs.existsSync(session)) {
	fs.mkdirSync(session, { recursive: true });
}

if (!fs.existsSync(storeFilePath)) {
	fs.writeFileSync(
		storeFilePath,
		JSON.stringify(
			{
				chats: [],
				contacts: {},
				messages: {},
				presences: {},
			},
			null,
			4
		)
	);
}

const debounceWrite = (() => {
	let timeout;
	return (callback) => {
		clearTimeout(timeout);
		timeout = setTimeout(() => callback(), 1000);
	};
})();

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const initialData = JSON.parse(fs.readFileSync(storeFilePath, 'utf-8'));

store.chats = initialData.chats || [];
store.contacts = initialData.contacts || {};
store.messages = initialData.messages || {};
store.presences = initialData.presences || {};

setInterval(() => {
	debounceWrite(() => {
		const formattedData = JSON.stringify(
			{
				chats: store.chats || [],
				contacts: store.contacts || {},
				messages: store.messages || {},
				presences: store.presences || {},
			},
			null,
			4
		);
		fs.writeFileSync(storeFilePath, formattedData);
	});
}, 10_000);

function printRainbowText(text, colors) {
	let colorIndex = 0;
	return text.split('').map(char => {
		const color = colors[colorIndex % colors.length];
		colorIndex++;
		return chalk.hex(color)(char);
	}).join('');
}

rainbowText.forEach(line => {
	console.log(printRainbowText(line, rainbowColors));
});

const bold = text => {
	const boldMap = {
		a: '𝝰', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵',
		i: '𝗶', j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽',
		q: '𝗾', r: '𝗿', s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝞈', x: '𝘅',
		y: '𝘆', z: '𝘇'
	};
	
	return text.toLowerCase().split('').map(char => 
		boldMap[char] || char
	).join('');
};

async function startHaruka() {
	const { state, saveCreds } = await useMultiFileAuthState(session)
	const { version, isLatest } = await fetchLatestBaileysVersion()
	const whatsappClient = makeWASocket({
		logger: pino({ level: "silent" }),
		printQRInTerminal: !usePairingCode,
		auth: state,
		version: version,
		browser: Browsers.ubuntu("Firefox"),
		generateHighQualityLinkPreview: true,
		syncFullHistory: true,
		markOnlineOnConnect: true,
		emitOwnEvents: true
	})

	whatsappClient.ev.on('creds.update', saveCreds)

	if (!whatsappClient.authState.creds.registered) {
		const rawNomor = await question(chalk.blue.bold('Masukkan Nomor WhatsApp kamu: \n'));
		await authenticateUserWithDomain(whatsappClient, rawNomor);
	}

	store.bind(whatsappClient.ev);

	whatsappClient.ev.on("connection.update", async (update) => {
		const { connection, lastDisconnect } = update;
		const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.statusCode;

		if (connection === "close") {
			switch (reason) {
				case DisconnectReason.badSession:
					console.log(`\nUps~ Ada kesalahan pada sesi! Hapus sesi dulu ya, lalu coba lagi! ✨`);
					process.exit();
					break;
				case DisconnectReason.connectionClosed:
					console.log('\nWaduh, koneksi terputus! Lagi coba nyambung lagi nih... 🔄');
					startHaruka();
					break;
				case DisconnectReason.connectionLost:
					console.log('\nKoneksi hilang dari server~ Sabar ya, coba nyambung lagi! 💫');
					startHaruka();
					break;
				case DisconnectReason.connectionReplaced:
					console.log('\nEh? Botnya nyambung ke server lain! Restart dulu ya~ 😳');
					process.exit();
					break;
				case DisconnectReason.loggedOut:
					console.log(`\nYah, perangkatnya keluar sendiri~ Hapus folder sesi dan scan ulang ya! 📝`);
					process.exit();
					break;
				case DisconnectReason.restartRequired:
					console.log('\nHmmm, perlu restart nih! Nyambung ulang ya... 🔁');
					startHaruka();
					break;
				case DisconnectReason.timedOut:
					console.log('\nKoneksi timeout~ Tenang, coba lagi ya! ⏳');
					startHaruka();
					break;
				default:
					console.log(`\nEh? Alasan nggak dikenal: ${reason} | ${connection} 🤔`);
					startHaruka();
					break;
			}
		} else if (connection === "connecting") {
			console.log('\nLagi nyoba nyambung nih~ Sabar ya! 💪');
		} else if (connection === "open") {
			console.log(chalk.blue.bold('\nYay! Botnya udah terkoneksi~ 🎉'));
		}
	});

	whatsappClient.ev.on('group-participants.update', async (anu) => {
		try {
			if (!anu.id || !anu.participants) return;
		
			const { welcome } = require('./lib/welcome');
			const iswel = db.data?.chats?.[anu.id]?.wlcm || false;
			const isLeft = db.data?.chats?.[anu.id]?.left || false;
		
			welcome(iswel, isLeft, whatsappClient, anu);
		} catch (err) {
			console.error('Error in group-participants.update:', err);
		}
	});

	whatsappClient.ev.on('call', async (call) => {
		if (anticall) {
			for (const callData of call) {
				if (callData.status === 'offer') {
					const callerId = callData.from;
					const callType = callData.isVideo ? 'video' : 'suara';

					await whatsappClient.sendMessage(callerId, {
						text: `Maaf, kami tidak dapat menerima panggilan ${callType} saat ini. 🙏\nJika Anda membutuhkan bantuan, silakan hubungi owner ya! 😊`,
						mentions: [callerId],
					});

					await whatsappClient.rejectCall(callData.id, callerId);
				}
			}
		}
	});

	whatsappClient.ev.on("messages.upsert", async (chatUpdate, msg) => {
		if (autoswview) {
			try {
				const msg = chatUpdate.messages[0];
				if (!msg.message) return;
				msg.message = (Object.keys(msg.message)[0] === 'ephemeralMessage') 
					? msg.message.ephemeralMessage.message
					: msg.message;

				if (msg.key && msg.key.remoteJid === 'status@broadcast') {
					if (msg.key.participant) {
						await whatsappClient.readMessages([msg.key]);
						await whatsappClient.sendMessage('status@broadcast', {
							react: {
								text: "💚",
								key: msg.key
							}
						}, {
							statusJidList: [msg.key.participant]
						});
					}
				}
			} catch (error) {
				console.error('Error:', error);
			}
		}
	});

	whatsappClient.ev.on('group-participants.update', async (event) => {
		if (adminevent) {
			console.log(event);
			try {
				const participants = event.participants;

				for (const participant of participants) {
					let userProfilePicture, groupProfilePicture;

					try {
						userProfilePicture = await whatsappClient.profilePictureUrl(participant, 'image');
					} catch (error) {
						userProfilePicture = imageUrl;
					}

					try {
						groupProfilePicture = await whatsappClient.profilePictureUrl(event.id, 'image');
					} catch (error) {
						groupProfilePicture = imageUrl;
					}

					const participantName = `@${participant.split('@')[0]}`;
					const time = moment.tz('Asia/Jakarta').format('HH:mm:ss');
					const date = moment.tz('Asia/Jakarta').format('DD/MM/YYYY');

					if (event.action === 'promote') {
					const promotionMessage = `🎉 *Selamat, ${participantName}!*\nAnda baru saja dipromosikan menjadi *admin* di grup ini. 🥳\n\nWaktu: ${time}\nTanggal: ${date}`;

						await whatsappClient.sendMessage(event.id, {
							text: promotionMessage,
							contextInfo: {
								mentionedJid: [participant],
								externalAdReply: {
									showAdAttribution: true,
									containsAutoReply: true,
									title: botName,
									body: ownerName,
									previewType: "PHOTO",
									thumbnailUrl: groupProfilePicture,
									sourceUrl: wagc
								}
							}
						});
					} else if (event.action === 'demote') {
						const demotionMessage = `😬 *Mohon maaf, ${participantName}.*\nAnda telah diturunkan dari posisi *admin* di grup ini.\n\nWaktu: ${time}\nTanggal: ${date}`;

						await whatsappClient.sendMessage(event.id, {
							text: demotionMessage,
							contextInfo: {
								mentionedJid: [participant],
								externalAdReply: {
									showAdAttribution: true,
									containsAutoReply: true,
									title: botName,
									body: ownerName,
									previewType: "PHOTO",
									thumbnailUrl: groupProfilePicture,
									sourceUrl: wagc
								}
							}
						});
					}
				}
			} catch (error) {
				console.error('❌ Terjadi kesalahan dalam memproses event admin:', error);
			}
		}
	});

	whatsappClient.ev.on("groups.update", async (groupUpdates) => {
		if (groupevent) {
			try {
				let groupProfilePicture = imageUrl;
				try {
					groupProfilePicture = await whatsappClient.profilePictureUrl(groupUpdates[0].id, 'image');
				} catch (error) {
					console.warn('⚠️ Gagal mendapatkan foto grup, menggunakan gambar default.');
				}

				const groupUpdate = groupUpdates[0];

				if (groupUpdate.announce === true) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🔒 *Grup Ditutup Sementara* 🔒\n\nHanya *admin* yang dapat mengirim pesan di grup ini. Terima kasih atas pengertiannya! 🙏✨`,
					});
				} else if (groupUpdate.announce === false) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🔓 *Grup Dibuka Kembali* 🔓\n\nSekarang semua anggota dapat mengirim pesan. Mari kita ramaikan grup ini! 🎉😊`,
					});
				}

				if (groupUpdate.restrict === true) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🔐 *Info Grup Dikunci* 🔐\n\nHanya *admin* yang dapat mengubah info grup. Mari menjaga ketertiban bersama! 😇📚`,
					});
				} else if (groupUpdate.restrict === false) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🔓 *Info Grup Dibuka* 🔓\n\nSemua anggota kini dapat mengubah info grup. Harap gunakan hak ini dengan bijak! 😊📢`,
					});
				}

				if (groupUpdate.desc) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `📝 *Deskripsi Grup Diperbarui* 📝\n\nBerikut adalah deskripsi terbaru grup ini:\n\n${groupUpdate.desc}\n\nSemoga informasi ini bermanfaat! 😍✨`,
					});
				}

				if (groupUpdate.subject) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🖊️ *Nama Grup Diperbarui* 🖊️\n\nGrup ini sekarang memiliki nama baru:\n\n*${groupUpdate.subject}*\n\nBagaimana, menarik bukan? 😎🔥`,
					});
				}

				if (groupUpdate.memberAddMode === true) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🛡️ *Tambah Anggota Dibatasi* 🛡️\n\nHanya *admin* yang dapat menambahkan anggota baru. Mari patuhi aturan bersama! 👀✨`,
					});
				} else if (groupUpdate.memberAddMode === false) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `✅ *Tambah Anggota Dibuka* ✅\n\nSekarang semua anggota dapat mengundang teman-teman mereka. Mari tambah kehangatan di grup ini! 🥳🎈`,
					});
				}

				if (groupUpdate.joinApprovalMode === true) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `🛡️ *Persetujuan Bergabung Diaktifkan* 🛡️\n\nCalon anggota baru memerlukan persetujuan *admin* untuk bergabung. Mari jaga keamanan grup! 🤝🔒`,
					});
				} else if (groupUpdate.joinApprovalMode === false) {
					await sleep(2000);
					await whatsappClient.sendMessage(groupUpdate.id, {
						text: `✅ *Persetujuan Bergabung Dinonaktifkan* ✅\n\nAnggota baru dapat langsung bergabung tanpa persetujuan admin. Mari sambut mereka dengan hangat! 🎊😊`,
					});
				}

			} catch (error) {
				console.error('❌ Terjadi kesalahan saat memproses pembaruan grup:', error);
			}
		}
	});

	whatsappClient.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			const msg = chatUpdate.messages[0];
			if (!msg.message) return;

			msg.message = (Object.keys(msg.message)[0] === 'ephemeralMessage') 
				? msg.message.ephemeralMessage.message 
				: msg.message;

			if (msg.key && msg.key.remoteJid === 'status@broadcast') return;

			const remoteJid = msg.key.remoteJid;
			const userId = msg.key.fromMe ? botNumber : msg.key.participant;
			const currentTimestamp = Date.now();

			if (!store.presences) store.presences = {};
			store.presences[userId] = { lastOnline: currentTimestamp };

			if (!store.messages[remoteJid]) store.messages[remoteJid] = [];

			const simplifiedMessage = {
				key: msg.key,
				messageTimestamp: msg.messageTimestamp,
				pushName: msg.pushName || null,
				message: msg.message
			};

			store.messages[remoteJid].push(simplifiedMessage);

			if (store.messages[remoteJid].length > 50) {
				store.messages[remoteJid] = store.messages[remoteJid].slice(-50);
			}

			if (!store.chats.some(chat => chat.id === remoteJid)) {
				store.chats.push({
					id: remoteJid,
					conversationTimestamp: msg.messageTimestamp || Date.now()
				});
			}

			const m = smsg(whatsappClient, msg, store);
			require('./case')(whatsappClient, m, chatUpdate, msg, store);

		} catch (err) {
			console.error(err);
		}
	});

	whatsappClient.decodeJid = (jid) => {
		if (!jid) return jid
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {}
			return decode.user && decode.server && decode.user + '@' + decode.server || jid
		} else return jid
	}

	whatsappClient.ev.on('contacts.update', update => {
		for (let contact of update) {
			let id = whatsappClient.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = {
				id,
				name: contact.notify
			}
		}
	})

	whatsappClient.getName = (jid, withoutContact = false) => {
		id = whatsappClient.decodeJid(jid)
		withoutContact = whatsappClient.withoutContact || withoutContact
		let v
		if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
			v = store.contacts[id] || {}
			if (!(v.name || v.subject)) v = whatsappClient.groupMetadata(id) || {}
			resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
		})
		else v = id === '0@s.whatsapp.net' ? {
			id,
			name: 'WhatsApp'
		} : id === whatsappClient.decodeJid(whatsappClient.user.id) ? whatsappClient.user : (store.contacts[id] || {})
		return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
	}

	whatsappClient.sendContact = async (jid, kontak, quoted = '', opts = {}) => {
		let list = []
		for (let i of kontak) {
			list.push({
				displayName: await whatsappClient.getName(i),
				vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await whatsappClient.getName(i)}\nFN:${await whatsappClient.getName(i)}\nitem1.TEL;waid=${i.split('@')[0]}:${i.split('@')[0]}\nitem1.X-ABLabel:Mobile\nEND:VCARD`
			})
		}
		whatsappClient.sendMessage(jid, { contacts: { displayName: ownerName, contacts: list }, ...opts }, { quoted })
	}

	whatsappClient.public = true

	whatsappClient.serializeM = (m) => smsg(whatsappClient, m, store);

	const uploadFile = {
		upload: whatsappClient.waUploadToServer
	};

	whatsappClient.sendButtonText = (jid, buttons = [], text, footer, quoted = '', options = {
		contextInfo: {
			mentionedJid: ments(text),
		}
	}) => {
		let button = []
		for (let i = 0; i < buttons.length; i++) {
			button.push({
				"name": buttons[i].name,
				"buttonParamsJson": JSON.parse(JSON.stringify(buttons[i].buttonParamsJson))
			})
		}
		let msg = generateWAMessageFromContent(jid, {
			viewOnceMessage: {
				message: {
					'messageContextInfo': {
						'deviceListMetadata': {},
						'deviceListMetadataVersion': 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						...options,
						mentionedJid: ments(text),
						body: proto.Message.InteractiveMessage.Body.create({
							text: bold(text)
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: footer
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title: "",
							hasMediaAttachment: false
						}),
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons: button,
						})
					})
				}
			}
		}, {
			quoted: quoted
		})

		whatsappClient.relayMessage(msg.key.remoteJid, msg.message, {
			messageId: msg.key.id
		})
		return msg
	}
	
	whatsappClient.sendButtonImage = async (jid, image, buttons = [], text, footer, quoted = '', options = {
		contextInfo: {
			mentionedJid: ments(text),
		}
	}) => {
		let button = []
		for (let i = 0; i < buttons.length; i++) {
			button.push({
				"name": buttons[i].name,
				"buttonParamsJson": JSON.parse(JSON.stringify(buttons[i].buttonParamsJson))
			})
		}
		var imageMessage = await prepareWAMessageMedia({
				image: image,
			},
			uploadFile,
		);
		let msg = generateWAMessageFromContent(jid, {
			viewOnceMessage: {
				message: {
					'messageContextInfo': {
						'deviceListMetadata': {},
						'deviceListMetadataVersion': 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						...options,
						body: proto.Message.InteractiveMessage.Body.create({
							text: ""
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: footer
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title: bold(text),
							subtitle: text,
							hasMediaAttachment: true,
							imageMessage: imageMessage.imageMessage
						}),
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons: button,
						})
					})
				}
			}
		}, {
			quoted: quoted
		})

		whatsappClient.relayMessage(msg.key.remoteJid, msg.message, {
			messageId: msg.key.id
		})
		return msg
	}

	whatsappClient.sendButtonVideo = async (jid, video, buttons = [], text, footer, quoted = '', options = {
		contextInfo: {
			mentionedJid: ments(text),
		}
	}) => {
		let button = []
		for (let i = 0; i < buttons.length; i++) {
			button.push({
				"name": buttons[i].name,
				"buttonParamsJson": JSON.parse(JSON.stringify(buttons[i].buttonParamsJson))
			})
		}
		var videoMessage = await prepareWAMessageMedia({
				video: video,
			},
			uploadFile,
		);
		let msg = generateWAMessageFromContent(jid, {
			viewOnceMessage: {
				message: {
					'messageContextInfo': {
						'deviceListMetadata': {},
						'deviceListMetadataVersion': 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						...options,
						body: proto.Message.InteractiveMessage.Body.create({
							text: ""
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: footer
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title: bold(text),
							subtitle: text,
							videoMessage: videoMessage.videoMessage,
							hasMediaAttachment: true
						}),
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons: button,
						})
					})
				}
			}
		}, {
			quoted: quoted
		})

		whatsappClient.relayMessage(msg.key.remoteJid, msg.message, {
			messageId: msg.key.id
		})
		return msg
	}

	whatsappClient.sendButtonDocument = async (jid, document = {}, buttons = [], text, footer, quoted = '', options = {
		contextInfo: {
			mentionedJid: ments(text),
		}
	}) => {
		let button = []
		for (let i = 0; i < buttons.length; i++) {
			button.push({
				"name": buttons[i].name,
				"buttonParamsJson": JSON.parse(JSON.stringify(buttons[i].buttonParamsJson))
			})
		}
		let msg = generateWAMessageFromContent(jid, {
			viewOnceMessage: {
				message: {
					'messageContextInfo': {
						'deviceListMetadata': {},
						'deviceListMetadataVersion': 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						...options,
						body: proto.Message.InteractiveMessage.Body.create({
							text: bold(text)
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: footer
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title: "",
							hasMediaAttachment: true,
							...(await prepareWAMessageMedia(document, {
								upload: whatsappClient.waUploadToServer
							}))
						}),
						gifPlayback: true,
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons: button,
						})
					})
				}
			}
		}, {
			quoted: quoted
		})

		await whatsappClient.relayMessage(msg.key.remoteJid, msg.message, {
			messageId: msg.key.id
		})
		return msg
	}

	whatsappClient.sendText = (jid, text, quoted = '', options) => whatsappClient.sendMessage(jid, {
		text: bold(text),
		...options
	}, {
		quoted,
		...options
	})

	whatsappClient.sendImage = async (jid, path, caption = '', quoted = '', options) => {
		let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		return await whatsappClient.sendMessage(jid, {
			image: buffer,
			caption: caption,
			...options
		}, {
			quoted
		})
	}

	whatsappClient.sendTextWithMentions = async (jid, text, quoted, options = {}) => whatsappClient.sendMessage(jid, {
		text: bold(text),
		mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
		...options
	}, {
		quoted
	})

	whatsappClient.sendFromOwner = async (jid, text, quoted, options = {}) => {
		for (const a of jid) {
			await whatsappClient.sendMessage(a + '@s.whatsapp.net', { text, ...options }, { quoted });
		}
	}

	whatsappClient.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		let buffer
		if (options && (options.packname || options.author)) {
			buffer = await writeExifImg(buff, options)
		} else {
			buffer = await imageToWebp(buff)
		}
		await whatsappClient.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
		.then( response => {
			fs.unlinkSync(buffer)
			return response
		})
	}

	whatsappClient.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		let buffer
		if (options && (options.packname || options.author)) {
			buffer = await writeExifVid(buff, options)
		} else {
			buffer = await videoToWebp(buff)
		}
		await whatsappClient.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
		return buffer
	}

	whatsappClient.sendImageAsStickerV2 = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		let buffer
		if (options && (options.packname || options.author)) {
			buffer = await writeExifImgV2(buff, options)
		} else {
			buffer = await imageToWebpV2(buff)
		}
		await whatsappClient.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
		.then( response => {
			fs.unlinkSync(buffer)
			return response
		})
	}

	whatsappClient.sendVideoAsStickerV2 = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		let buffer
		if (options && (options.packname || options.author)) {
			buffer = await writeExifVidV2(buff, options)
		} else {
			buffer = await videoToWebpV2(buff)
		}
		await whatsappClient.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
		return buffer
	}

	whatsappClient.sendAudio = async (jid, path, quoted = '', ptt = false, options) => {
		let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		return await whatsappClient.sendMessage(jid, { audio: buffer, ptt: ptt, ...options }, { quoted })
	}

	whatsappClient.sendVideo = async (jid, path, caption = '', quoted = '', gif = false, options) => {
		let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
		return await whatsappClient.sendMessage(jid, { video: buffer, caption: caption, gifPlayback: gif, ...options }, { quoted })
	}

	whatsappClient.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
		let mime = '';
		let res = await axios.head(url)
		mime = res.headers['content-type']
		if (mime.split("/")[1] === "gif") {
			 return whatsappClient.sendMessage(jid, { video: await getBuffer(url), caption: caption, gifPlayback: true, ...options}, { quoted: quoted, ...options})
		}
		let type = mime.split("/")[0]+"Message"
		if (mime === "application/pdf"){
			return whatsappClient.sendMessage(jid, { document: await getBuffer(url), mimetype: 'application/pdf', caption: caption, ...options}, { quoted: quoted, ...options })
		}
		if (mime.split("/")[0] === "image"){
			return whatsappClient.sendMessage(jid, { image: await getBuffer(url), caption: caption, ...options}, { quoted: quoted, ...options})
		}
		if (mime.split("/")[0] === "video"){
			return whatsappClient.sendMessage(jid, { video: await getBuffer(url), caption: caption, mimetype: 'video/mp4', ...options}, { quoted: quoted, ...options })
		}
		if (mime.split("/")[0] === "audio"){
			return whatsappClient.sendMessage(jid, { audio: await getBuffer(url), caption: caption, mimetype: 'audio/mpeg', ...options}, { quoted: quoted, ...options })
		}
	}

	function getTypeMessage(message) {
		const type = Object.keys(message)
		var restype = (!['senderKeyDistributionMessage', 'messageContextInfo'].includes(type[0]) && type[0]) || 
			(type.length >= 3 && type[1] !== 'messageContextInfo' && type[1]) || 
			type[type.length - 1] || Object.keys(message)[0] 
		return restype
	};

	whatsappClient.getFile = async (PATH, save) => {
		let res
		let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
		//if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
		let type = await FileType.fromBuffer(data) || {
			mime: 'application/octet-stream',
			ext: '.bin'
		}
		filename = path.join(__filename, '../temp/' + new Date * 1 + '.' + type.ext)
		if (data && save) fs.promises.writeFile(filename, data)
		return {
			res,
			filename,
			size: await getSizeMedia(data),
			...type,
			data
		}
	}

	whatsappClient.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
		let type = await whatsappClient.getFile(path, true);
		let { res, data: file, filename: pathFile } = type;
		if (res && res.status !== 200 || file.length <= 65536) {
		try {
			throw {
				json: JSON.parse(file.toString())
			};
		} catch (e) {
			if (e.json) throw e.json;
		}
	}
	let opt = {
		filename
	};
	if (quoted) opt.quoted = quoted;
	if (!type) options.asDocument = true;
	let mtype = '',
	mimetype = type.mime,
	convert;
	if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
	else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
	else if (/video/.test(type.mime)) mtype = 'video';
	else if (/audio/.test(type.mime)) {
		convert = await (ptt ? toPTT : toAudio)(file, type.ext);
		file = convert.data;
		pathFile = convert.filename;
		mtype = 'audio';
		mimetype = 'audio/ogg; codecs=opus';
	} else mtype = 'document';
		if (options.asDocument) mtype = 'document';
		delete options.asSticker;
		delete options.asLocation;
		delete options.asVideo;
		delete options.asDocument;
		delete options.asImage;
		let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
		let m;
		try {
			m = await whatsappClient.sendMessage(jid, message, { ...opt, ...options });
		} catch (e) {
			console.error(e)
			m = null;
		} finally {
			if (!m) m = await whatsappClient.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
			file = null;
			return m;
		}
	}

	whatsappClient.sendPoll = (jid, name = '', values = [], selectableCount = global.select) => {
		return whatsappClient.sendMessage(jid, {
			poll: {
				name,
				values,
				selectableCount
			}
		})
	};

	whatsappClient.cMod = (jid, copy, text = '', sender = whatsappClient.user.id, options = {}) => {
		let mtype = Object.keys(copy.message)[0]
		let isEphemeral = mtype === 'ephemeralMessage'
		if (isEphemeral) {
			mtype = Object.keys(copy.message.ephemeralMessage.message)[0]
		}
		let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
		let content = msg[mtype]
		if (typeof content === 'string') msg[mtype] = text || content
		else if (content.caption) content.caption = text || content.caption
		else if (content.text) content.text = text || content.text
		if (typeof content !== 'string') msg[mtype] = {
			...content,
			...options
		}
		if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
		else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
		if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
		else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
		copy.key.remoteJid = jid
		copy.key.fromMe = sender === whatsappClient.user.id

		return proto.WebMessageInfo.fromObject(copy)
	}

	whatsappClient.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
		let types = await whatsappClient.getFile(path, true)
		let { mime, ext, res, data, filename } = types
		if (res && res.status !== 200 || file.length <= 65536) {
			try { throw { json: JSON.parse(file.toString()) } }
			catch (e) { if (e.json) throw e.json }
		}
		let type = '', mimetype = mime, pathFile = filename
		if (options.asDocument) type = 'document'
		if (options.asSticker || /webp/.test(mime)) {
			let { writeExif } = require('./lib/exif')
			let media = { mimetype: mime, data }
			pathFile = await writeExif(media, { packname: options.packname ? options.packname : global.packname, author: options.author ? options.author : global.author, categories: options.categories ? options.categories : [] })
			await fs.promises.unlink(filename)
			type = 'sticker'
			mimetype = 'image/webp'
		}
		else if (/image/.test(mime)) type = 'image'
		else if (/video/.test(mime)) type = 'video'
		else if (/audio/.test(mime)) type = 'audio'
		else type = 'document'
		await whatsappClient.sendMessage(jid, { [type]: { url: pathFile }, caption, mimetype, fileName, ...options }, { quoted, ...options })
		return fs.promises.unlink(pathFile)
	}

	whatsappClient.copyNForward = async (jid, message, forceForward = false, options = {}) => {
		let vtype
		if (options.readViewOnce) {
			message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
			vtype = Object.keys(message.message.viewOnceMessage.message)[0]
			delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
			delete message.message.viewOnceMessage.message[vtype].viewOnce
			message.message = {
				...message.message.viewOnceMessage.message
			}
		}
		let mtype = Object.keys(message.message)[0]
		let content = await generateForwardMessageContent(message, forceForward)
		let ctype = Object.keys(content)[0]
		let context = {}
		if (mtype != "conversation") context = message.message[mtype].contextInfo
		content[ctype].contextInfo = {
			...context,
			...content[ctype].contextInfo
		}
		const waMessage = await generateWAMessageFromContent(jid, content, options ? {
			...content[ctype],
			...options,
			...(options.contextInfo ? {
				contextInfo: {
					...content[ctype].contextInfo,
					...options.contextInfo
				}
			} : {})
		} : {})
		await whatsappClient.relayMessage(jid, waMessage.message, { messageId:waMessage.key.id })
		return waMessage
	}

	whatsappClient.ments = (text = '') => {
		return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
	};

	whatsappClient.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
		let quoted = message.msg ? message.msg : message
		let mime = (message.msg || message).mimetype || ''
		let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
		const stream = await downloadContentFromMessage(quoted, messageType)
		let buffer = Buffer.from([])
		for await(const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk])
		}
		let type = await FileType.fromBuffer(buffer)
		let trueFileName = attachExtension ? ('./temp/' + filename + '.' + type.ext) : './temp/' + filename
		await fs.writeFileSync(trueFileName, buffer)
		return trueFileName
	}

	whatsappClient.downloadMediaMessage = async (message) => {
		let mime = (message.msg || message).mimetype || ''
		let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
		const stream = await downloadContentFromMessage(message, messageType)
		let buffer = Buffer.from([])
		for await(const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk])
		}

		return buffer
	}
 
	return whatsappClient
};

const code = fs.readFileSync("./case.js", "utf8");
var regex = /case\s+'([^']+)':/g;
var matches = [];
var match;
while ((match = regex.exec(code))) {
	matches.push(match[1]);
}
global.help = Object.values(matches).flatMap(v => v ?? []).map(entry => entry.trim().split(' ')[0].toLowerCase()).filter(Boolean);
global.handlers = [];
const handlersDir = path.join(__dirname, 'plugins');
console.log(chalk.white.bold("Memuat plugin..."))
fs.readdirSync(handlersDir).forEach(file => {
	const filePath = path.join(handlersDir, file);
	if (fs.statSync(filePath).isFile() && file.endsWith('.js')) {
		const handler = require(filePath);
		global.handlers.push(handler);
		global.help.push(...handler.command)
		console.log(chalk.green(filePath))
	}
});

startHaruka();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.yellow.bold(`\n⚠️ ${__filename} telah diperbarui! ⚠️`));
	console.log(chalk.green("🔄 Silakan restart bot untuk menerapkan perubahan.\n"));
	delete require.cache[file]
	require(file)
});