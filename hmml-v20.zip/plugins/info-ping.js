const { fetchJson } = require("../lib/myfunc");
const osUtils = require('node-os-utils');
const os = require('os');
const moment = require('moment-timezone');
const process = require('process');

let handler = async (m, { isPremium, text, usedPrefix, command }) => {
	try {
		const cpu = osUtils.cpu;
		const mem = osUtils.mem;
		const drive = osUtils.drive;
		const netstat = osUtils.netstat;

		const cpuUsage = await cpu.usage();
		const cpuCount = cpu.count();
		const cpuCores = os.cpus();

		const memInfo = await mem.info();
		const driveInfo = await drive.info();

		const osPlatform = os.platform();
		const osType = os.type();
		const osRelease = os.release();
		const osArch = os.arch();
		const osUptime = moment.duration(os.uptime(), 'seconds').humanize();

		const botUptime = moment.duration(process.uptime(), 'seconds').humanize();
		const nodeVersion = process.version;
		const botMemoryUsage = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);

		const now = moment().tz('Asia/Jakarta');
		const todayDate = now.format('YYYY-MM-DD');
		const todayTime = now.format('HH:mm:ss');

		// Info tambahan menggunakan systeminformation
		const loadAvg = os.loadavg().map(l => l.toFixed(2)).join(", ");
		const networkStats = await netstat.inOut();
		
		let infoMessage = `
╭───❑ 「 *BOT STATUS* 」 ❑────
│📡 *CPU Usage:* ${cpuUsage}%
│🖥️ *CPU Cores:* ${cpuCount}
│⚙️ *Load Average:* ${loadAvg}
│
│💾 *Memory Usage:*
│	├ *Total:* ${(memInfo.totalMemMb / 1024).toFixed(2)} GB
│	├ *Used:* ${(memInfo.usedMemMb / 1024).toFixed(2)} GB
│	└ *Free:* ${(memInfo.freeMemMb / 1024).toFixed(2)} GB
│
│📀 *Storage:*
│	├ *Total:* ${driveInfo.totalGb} GB
│	├ *Used:* ${driveInfo.usedGb} GB
│	└ *Free:* ${driveInfo.freeGb} GB
│
│🌐 *Network:*
│	├ *Upload:* ${networkStats.total.outputMb} MB
│	└ *Download*: ${networkStats.total.inputMb} MB
│
│🖥️ *OS Info:*
│	├ *Platform:* ${osPlatform}
│	├ *Type:* ${osType}
│	├ *Version:* ${osRelease}
│	├ *Arch:* ${osArch}
│	└ *Uptime:* ${osUptime}
│
│🤖 *Bot Info:*
│	├ *Uptime:* ${botUptime}
│	├ *Node.js:* ${nodeVersion}
│	├ *RAM Usage:* ${botMemoryUsage} MB
│	├ *Date:* ${todayDate}
│	└ *Time:* ${todayTime}
╰❑────────────❑
`.trim();

		m.reply(infoMessage);
	} catch (error) {
		console.error(error);
		m.reply('⚠️ *Terjadi kesalahan saat mengambil informasi sistem.*');
	}
};

handler.command = ["ping", "status"];
handler.tags = ["info"];
handler.help = ["ping", "status"].map(cmd => `${cmd}`);

module.exports = handler;
