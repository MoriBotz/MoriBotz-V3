const axios = require('axios');

let handler = async (m, { text, usedPrefix, command }) => {
	try {
		if (!text) throw `Hee~ kamu lupa ngetik nama package-nya! 🥺\nCoba gini: ${usedPrefix + command} axios`;

		const packageName = text.trim();
		const npmUrl = `https://registry.npmjs.org/${packageName}`;
		const { data: packageInfo } = await axios.get(npmUrl);

		if (!packageInfo || packageInfo.error) throw `Ehh?! Package *"${packageName}"* gak ketemu… 😢`;

		const latestVersion = packageInfo['dist-tags'].latest;
		const latestVersionInfo = packageInfo.versions[latestVersion];

		const downloadStatsUrl = `https://api.npmjs.org/downloads/point/last-week/${packageName}`;
		const { data: downloadStats } = await axios.get(downloadStatsUrl);

		const infoMessage = `
✨ *Informasi Package NPM* ✨

📦 *Nama:* ${packageInfo.name}
🔖 *Versi Terbaru:* ${latestVersion}
📝 *Deskripsi:* ${latestVersionInfo.description || "Tidak ada deskripsi~"}
👤 *Author:* ${latestVersionInfo.author?.name || "Tidak diketahui >_<"}
🧾 *Lisensi:* ${latestVersionInfo.license || "Rahasia kali yaa~"}

📊 *Statistik Unduhan Minggu Ini:* ${downloadStats.downloads || 0} unduhan 💥

🧩 *Dependensi:* ${latestVersionInfo.dependencies ? Object.keys(latestVersionInfo.dependencies).join(', ') : "Tidak ada dependensi~"}

🌐 *Repository:* ${latestVersionInfo.repository?.url || "Gak tersedia 😓"}
🏠 *Homepage:* ${latestVersionInfo.homepage || "Gak ada homepage-nya~"}
		`;

		m.reply(infoMessage.trim());
	} catch (error) {
		console.error(error);
		m.reply(`Hiks… gagal ngambil info package 😭\nAlasannya: ${error.message || error}`);
	}
};

handler.command = ["npminfo"];
handler.tags = ["search"];
handler.help = ["npminfo"].map(cmd => `${cmd}`);

module.exports = handler;
