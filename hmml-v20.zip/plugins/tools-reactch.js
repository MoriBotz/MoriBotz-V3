let handler = async (m, { whatsappClient, isOwner, text, usedPrefix, command }) => {
	if (!isOwner) return m.react('🖕🏻');
	if (!text) return m.reply("Masukkan link channel WhatsApp dengan format yang benar.");

	const match = text.match(/https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/);
	if (!match) return m.reply("URL tidak valid. Silakan periksa kembali.");

	const channelId = match[1];
	const chatId = match[2];
	if (!chatId) return m.reply("ID chat tidak ditemukan dalam link yang diberikan.");

	await whatsappClient.newsletterMetadata("invite", channelId).then(data => {
		if (!data) return m.reply("Newsletter tidak ditemukan atau terjadi kesalahan.");
		
		whatsappClient.newsletterReactMessage(data.id, chatId, text.split(" ").slice(1).join(" ") || "😋");
	})
	m.reply("Done! ✅");
};

handler.command = ["reactch", "reactchannel"]
handler.tags = ["tools"]
handler.help = ["reactch", "reactchannel"].map((a) => a + " <url>")
module.exports = handler