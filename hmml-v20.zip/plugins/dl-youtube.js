const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { tmpdir } = require('os');
const { promisify } = require('util');

const writeFileAsync = promisify(fs.writeFile);
const unlinkAsync = promisify(fs.unlink);

const CONFIG = {
	cookiesPath: path.join(__dirname, 'cookies.txt'),
	tempDir: tmpdir(),
	maxTitleLength: 40,
	retryCount: 3
};

const bold = text => {
	const boldMap = {
		a: '𝝰', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵',
		i: '𝗶', j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽',
		q: '𝗾', r: '𝗿', s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝞈', x: '𝘅',
		y: '𝘆', z: '𝘇'
	};
	
	return text.toLowerCase().split('').map(char => 
		boldMap[char] || char
	).join('');
};

const runYtDlp = (args) => {
	const baseArgs = fs.existsSync(CONFIG.cookiesPath) 
		? ['--cookies', CONFIG.cookiesPath] 
		: [];
	
	baseArgs.push(
		'--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
		'--limit-rate', '1M',
		'--retries', CONFIG.retryCount.toString()
	);

	try {
		return execFileSync('./yt-dlp', baseArgs.concat(args)).toString();
	} catch (error) {
		throw new Error(bold(`yt-dlp error: ${error.stderr?.toString() || error.message}`));
	}
};

const getVideoData = async (url) => {
	try {
		const output = runYtDlp(['--dump-json', '--no-warnings', '--skip-download', url]);
		const info = JSON.parse(output);
		
		return {
			id: info.id,
			title: info.title,
			duration: formatDuration(info.duration),
			thumbnail: info.thumbnail || info.thumbnails?.[0]?.url || ''
		};
	} catch (error) {
		throw new Error(bold(`failed to fetch video data: ${error.message}`));
	}
};

const downloadMedia = async (url, format, title) => {
	const cleanTitle = title.replace(/[^\w\s]/gi, '').replace(/\s+/g, '_');
	const filePath = path.join(CONFIG.tempDir, `${cleanTitle}_${Date.now()}.${format}`);

	const args = [
		'-o', filePath,
		'--no-warnings',
		'--force-overwrites',
		...(format === 'mp3' 
			? ['-x', '--audio-format', 'mp3', '--audio-quality', '0', '--embed-metadata', '--embed-thumbnail'] 
			: ['-f', 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]', '--merge-output-format', 'mp4']),
		url
	];

	runYtDlp(args);
	if (!fs.existsSync(filePath)) throw new Error(bold('download failed - file not created'));
	return filePath;
};

const handler = async (m, { whatsappClient, args, usedPrefix, command }) => {
	if (!args[0]) {
		return whatsappClient.sendMessage(m.chat, {
			text: bold(`invalid command\n\nusage: ${usedPrefix}${command} <youtube-url>`)
		}, { quoted: m });
	}

	try {
		const url = args[0];
		const format = command === 'ytmp3' ? 'mp3' : 'mp4';

		await whatsappClient.sendMessage(m.chat, { 
			text: bold(`Audio sedang di-download, tunggu sebentar ya kak~`) 
		}, { quoted: m });

		const videoData = await getVideoData(url);
		const mediaPath = await downloadMedia(url, format, videoData.title);
		
		await whatsappClient.sendMessage(m.chat, {
			[format === 'mp3' ? 'audio' : 'video']: fs.readFileSync(mediaPath),
			mimetype: format === 'mp3' ? 'audio/mpeg' : 'video/mp4',
			caption: bold(`${format} proses selesai, dan download berhasil~\n\n${videoData.title}`)
		}, { quoted: m });

		await unlinkAsync(mediaPath);
		await whatsappClient.sendMessage(m.chat, { 
			text: bold(`process completed`) 
		}, { quoted: m });

	} catch (error) {
		await whatsappClient.sendMessage(m.chat, { 
			text: bold(`error occurred\n\n${error.message}`) 
		}, { quoted: m });
	}
};

handler.help = ['ytmp3', 'ytmp4'];
handler.tags = ['downloader'];
handler.command = ['ytmp3', 'ytmp4'];

module.exports = handler;

const formatDuration = (seconds) => {
	if (!seconds) return '00:00';
	const date = new Date(seconds * 1000);
	const mm = date.getUTCMinutes();
	const ss = date.getUTCSeconds();
	return `${mm}:${ss.toString().padStart(2, '0')}`;
};