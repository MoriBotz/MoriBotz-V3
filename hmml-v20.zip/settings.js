const fs = require("fs");
const chalk = require("chalk");
global.WHATSAPP_API = "himmel-api";

global.botName = "𝗵𝗶𝗺𝗺𝗲𝗹 𝗯𝗼𝘁";
global.botNumber = "6283856877894";
global.ownerName = "𝗵𝗶𝗺𝗺𝗲𝗹𝗰𝗹𝗼𝘂𝗱𝘀";
global.ownerNumber = "6285655548594";
global.website = "https://www.ryzenoffc.my.id";
global.wagc = "https://www.ryzenoffc.my.id";

global.packname = botName;
global.author = ownerName;
global.footer = "© 2025 · 𝗵𝗶𝗺𝗺𝗲𝗹𝗰𝗹𝗼𝘂𝗱𝘀";
global.creator = "6285655548594@s.whatsapp.net";
global.owner = ["6285655548594"];
global.premium = ["6285655548594"];
global.prefa = ".";
global.tempatDB = "database.json";

global.GROUP_JID = "0@g.us";
global.BOT_JID = "6283856877894@s.whatsapp.net";
global.saluran = "120363364330631981@newsletter";
global.saluranName = "Newsletter 🗞️";
global.sessionName = "session";

global.panel = "https://panel.ryzenoffc.my.id";
global.cred = "ptla_QviENVCLWpKZ2EN8NTjpo6TLrJ0lAyQN5ntLiCJwCrR";
global.apiuser = "ptlc_Jf5x1KilIVvmJrlt6lvhUiemWKYFdfhYlKw5GiZQ1GJ";
global.eggs = "16";
global.nets = "5";
global.location = "1";

global.YOUR_API_KEY = "JhwKI5";

global.CF_API_KEY = "kDVfZ8NWOFNCsloIA6ckd58duuYZ0nlXwysSV";
global.CF_ZONE_ID = "b9883610d0c1ecf9c83f0028978226";
global.CF_DOMAIN = "ryzenoffc.my.id";

global.APP_EMAIL = "cs.moraai@gmail.com";
global.APP_PASSWORD = "rwak vblz ttol ftdx";

global.typemenu = "v1";
global.typereply = "v6";
global.autoblocknumber = "62";
global.antiforeignnumber = "62";
global.welcome = true;
global.anticall = true;
global.autoswview = true;
global.adminevent = true;
global.groupevent = true;
global.onlyRegister = true;

global.payment = {
	dana: "+62 856-5554-8594",
	gopay: "+62 856-5554-8594",
	ovo: "+62 856-5554-8594",
	qris: "./media/QRIS.png"
};

global.limit = {
	free: 20,
	premium: "Infinity",
	vip: "Infinity"
};

global.uang = {
	free: 10000,
	premium: 1000000000,
	vip: 1000000000
};

global.bot = {
	limit: 1,
	uang: 1
};

global.game = {
	suit: {},
	menfes: {},
	tictactoe: {},
	kuismath: {},
	tebakbom: {}
};

global.mess = {
	limit: "ᴇᴇʜ~ ᴋᴀᴍᴜ ᴜᴅᴀʜ ᴍᴇɴᴄᴀᴘᴀɪ ʙᴀᴛᴀs ᴘᴇɴɢɢᴜɴᴀᴀɴ! sᴀʙᴀʀ ᴅᴜʟᴜ ʏᴀᴀ, ᴄᴏʙᴀ ʟᴀɢɪ ɴᴀɴᴛɪ~ 😣✨",
	nsfw: "ʜᴍᴘʜ! ᴋᴏɴᴛᴇɴ ᴅᴇᴡᴀsᴀ ɴɢɢᴀᴋ ᴅɪɪᴢɪɴᴋᴀɴ ᴅɪ sɪɴɪ, ᴛᴀʜᴜ! ᴛᴀɴʏᴀᴋᴀɴ ᴀᴅᴍɪɴ ᴅᴜʟᴜ, ᴅᴀsᴀʀ ᴍᴇsᴜᴍ~ 😳🚫",
	done: "ʜᴇʜᴇ~ ʙᴇʀʜᴀsɪʟ ᴅᴇʜ! ᴍᴜᴅᴀʜ ᴋᴀɴ? ᴊᴀɴɢᴀɴ ᴛᴇʀʟᴀʟᴜ ʙᴇʀɢᴀɴᴛᴜɴɢ ᴘᴀᴅᴀᴋᴜ ʏᴀ~ 😏💕",
	error: "ᴜɢʜ... ᴀᴅᴀ ʏᴀɴɢ sᴀʟᴀʜ ɴɪʜ! ᴄᴏʙᴀ ʟᴀɢɪ ʏᴀ, ᴊᴀɴɢᴀɴ ɴʏᴇʀᴀʜ! 😖💦",
	success: "ʏᴀᴛᴛᴀ~! ʙᴇʀʜᴀsɪʟ~ ɴɪʜ ʜᴀsɪʟɴʏᴀ ʙᴜᴀᴛᴍᴜ~ 😆🎉",
	owner: "ᴇɪᴛs, ᴄᴜᴍᴀ ᴘᴇᴍɪʟɪᴋᴋᴜ ʏᴀɴɢ ʙᴏʟᴇʜ ᴘᴀᴋᴀɪ ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ~ ᴊᴀɴɢᴀɴ ɴᴀᴋᴀʟ ʏᴀ~ 😤💢",
	botAdmin: "ᴀᴋᴜ ʙᴜᴛᴜʜ ᴊᴀᴅɪ ᴀᴅᴍɪɴ ᴅᴜʟᴜ ɴɪʜ ʙᴜᴀᴛ ɪᴛᴜ! ᴄᴇᴘᴇᴛᴀɴ ᴀᴛᴜʀ ᴅᴏɴɢ~ 😒👮‍♀️",
	admin: "ᴄᴜᴍᴀ ᴀᴅᴍɪɴ ɢʀᴜᴘ ʏᴀɴɢ ʙᴏʟᴇʜ, ᴋᴀᴍᴜ ʙᴇʟᴜᴍ ᴄᴜᴋᴜᴘ ᴋᴇʀᴇɴ ʙᴜᴀᴛ ɪᴛᴜ~ 😜✨",
	group: "ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ᴄᴜᴍᴀ ʙᴜᴀᴛ ᴅɪ ɢʀᴜᴘ ʏᴀ, ᴊᴀɴɢᴀɴ ɪsᴇɴɢ ᴅɪ ᴛᴇᴍᴘᴀᴛ ʟᴀɪɴ~ 🙅‍♀️",
	private: "ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ᴄʜᴀᴛ ᴘʀɪʙᴀᴅɪ, ᴊᴀᴅɪ ʙɪsɪᴋ-ʙɪsɪᴋ ᴀᴊᴀ ʏᴀ~ 🤫💕",
	bot: "ᴄᴜᴍᴀ ʙᴜᴀᴛ ʙᴏᴛ ᴀᴊᴀ sɪʜ~ ᴋᴀᴍᴜ ɴɢɢᴀᴋ ʙɪsᴀ~ 😝🤖",
	wait: "ᴜ-ᴜʜ... sᴀʙᴀʀ ᴅɪᴋɪᴛ ᴅᴏɴɢ! ᴀᴋᴜ ʟᴀɢɪ ᴘʀᴏsᴇs ɴɪʜ~ 😣⏳",
	premium: "ғɪᴛᴜʀ ɪɴɪ ʙᴜᴀᴛ ᴘᴇɴɢɢᴜɴᴀ ᴘʀᴇᴍɪᴜᴍ ᴀᴊᴀ~ ʏᴜᴋ ᴜᴘɢʀᴀᴅᴇ ᴅᴜʟᴜ~ ✨👑",
	banned: "ʜᴇʜ, ᴋᴀᴍᴜ ᴋᴇɴᴀ ʙᴀɴɴᴇᴅ! ᴘᴀsᴛɪ ɴᴀᴋᴀʟ ʙᴀɴɢᴇᴛ sɪʜ... 😤🚫",
	unban: "ʏᴇᴀʏ! ᴋᴀᴍᴜ ᴜᴅᴀʜ ᴅɪ-ᴜɴʙᴀɴ~ ᴊᴀɴɢᴀɴ ɴᴀᴋᴀʟ ʟᴀɢɪ ʏᴀᴀ~ 😆✨",
	restrict: "ғɪᴛᴜʀ ɪɴɪ ɴɢɢᴀᴋ ᴀᴋᴛɪғ ᴅɪ sɪɴɪ. ɴɢᴇʀᴛɪ ᴋᴀɴ? ᴊᴀɴɢᴀɴ ᴍᴀᴋsᴀ~ 😏❌"
};

global.imageUrl = "https://files.catbox.moe/bhir1q.jpg";
global.imageBuffer = fs.readFileSync("./media/imageBuffer.png");
global.audioBuffer = fs.readFileSync("./media/menu.mp3");

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(chalk.yellow.bold(`\n⚠️ ${__filename} telah diperbarui! ⚠️`));
	console.log(chalk.green("🔄 Silakan restart bot untuk menerapkan perubahan.\n"));
	delete require.cache[file];
	require(file);
});